

for exponent=[6,8,10]
    for n=[5,10,20]

EnergyE(exponent,n).S
%L2weigES(exponent,n).S
%H1E(exponent,n).S
%L2E(exponent,n).S
    end
end
