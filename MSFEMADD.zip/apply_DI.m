function xi=apply_DI(x,dom,i1,i2)

phi=dom(i1,i2).phiC;
xi=x.*phi;
