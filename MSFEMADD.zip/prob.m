
m1=20; % number of eigenvalues
m2=20;
m3=10;

W1=prob1(m1);
W2=prob2(m2);
W3=prob3(m3);




