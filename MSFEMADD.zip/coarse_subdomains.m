function coarse_subdomains(dom,Nx,Ny)

