function a=coeficientcont(x1,x2, mu)


a=1+mu*x1+mu*x2;
