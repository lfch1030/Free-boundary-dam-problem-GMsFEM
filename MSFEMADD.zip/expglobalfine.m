exp1
%coarsetestwv
close all
eigentestfull
[M0,dir,dirn,vC,P1]=coarse_matrixMBAD(dom,dom_ov,Nx,Ny);
eigentest
globalfine

