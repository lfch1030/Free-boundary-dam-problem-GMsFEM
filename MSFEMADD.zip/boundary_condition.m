function z=boundary_condition(x,y)

z=x+y;

