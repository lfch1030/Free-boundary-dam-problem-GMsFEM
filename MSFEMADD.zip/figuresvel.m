figure(11)
plot_piecewisevel2D(xf,dom,Nx,Ny,mu,k1perm); view(2);
%figure(12)
%plot_piecewisevel2D(z0MS,dom,Nx,Ny,mu,k1perm); view(2);
figure(14)
plot_piecewisevel2D(z02C,dom,Nx,Ny,mu,k1perm); view(2);