plot_grad_comp(x2L+xd,dom,Nx,Ny,mu,k1perm)
 hold on
%plot_coeff(dom,Nx,Ny,mu,k1perm)
%image(k1perm')
%plot_vector(x2L,dom,Nx,Ny,mu)
%plot_grad_comp(x2L,dom,Nx,Ny,mu,k1perm)
 hold on

alpha(0.3)