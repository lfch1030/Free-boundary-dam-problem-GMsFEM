function plotnew_coeff(dom,Nx,Ny)
% function plot_vector(u,dom,Nx,Ny)

for i1=1:Nx
    for i2=1:Ny
        M=dom(i1,i2).M;
        v=dom(i1,i2).vnew;
        col=dom(i1,i2).Ig;
        trisurf(M,v(:,1),v(:,2),coeficient(v(:,1),v(:,2)));
        hold on
%        pause
    end
end

xlabel('x')
ylabel('y')

