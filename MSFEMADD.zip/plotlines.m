
% Nx=10
for i=1:Nx+1
plot([0,1], [(i-1)/Nx,(i-1)/Nx],'-g','LineWidth',2)
hold on
plot([(i-1)/Nx,(i-1)/Nx], [0,1],'-g','LineWidth',2)

end
