function a=der1(x1,x2)
% function a=coeficient(x,y)
 n=1; m=2;
% a=1+0*x1+0*x2;
a=1./sqrt(coeficient2(x1,x2));
%a=(1/2)*(x2<=.5)+ (1+1/2)*(x2>.5);

%a=100*mod(floor(10*x1+10*x2),2)+1;
%a=x1*0+1;